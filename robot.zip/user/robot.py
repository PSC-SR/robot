print "Starting the robot... "

import os

print "Execution of robotpy about to take place"

os.system(os.path.abspath("robotpy/run.py") + "arg")